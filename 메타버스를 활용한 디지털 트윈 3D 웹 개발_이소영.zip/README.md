# r3f-mini-project

3D - card Interaction [Three.js]
